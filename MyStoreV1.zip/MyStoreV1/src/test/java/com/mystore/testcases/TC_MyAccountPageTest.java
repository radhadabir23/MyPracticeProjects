package com.mystore.testcases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mystore.pageobject.accountCreationDetails;
import com.mystore.pageobject.indexPage;
import com.mystore.pageobject.myAccount;
import com.mystore.pageobject.registeredUserAccount;

public class TC_MyAccountPageTest extends BaseClass {
	
	@Test(enabled=false)
	public void verifyRegistrationAndLogin() {
		// LaunchBrowser
		
		indexPage pg =new indexPage(driver);
		pg.clickOnSignIn();
		logger.info("Clicked on SignIn Button");
		
		myAccount myAccpg = new myAccount(driver);
		myAccpg.enterCreateEmailAddress("radhadabir@gmail.com");
		logger.info("entered email");
		myAccpg.clickSubmit();
		logger.info("Clicked on submit  Button");
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		accountCreationDetails accCreationPg = new accountCreationDetails(driver);
		
		accCreationPg.selectTitleMr();
		logger.info("title mr is selected");
		accCreationPg.enterCustomerFirstName("Radha");
		logger.info("entered first name");
		accCreationPg.enterCustomersLastName("dabir");
		logger.info("entered last name");
		accCreationPg.enterPassword("radhadabir");
		logger.info("entered password");
		accCreationPg.Register();
		logger.info("clicked on register button");
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		registeredUserAccount registeredUserAcc = new registeredUserAccount(driver);
		String username = registeredUserAcc.getUserName();
		
		Assert.assertEquals("Krushna rathod", username); 
		logger.info("verified username");
		
		
		
	}
	@Test
	public void verifyLogin() throws IOException {
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		indexPage pg =new indexPage(driver);
		pg.clickOnSignIn();
		logger.info("Clicked on SignIn Button");
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		myAccount myAccpg = new myAccount(driver);
		myAccpg.enterLoginEmailAddress("radhadabir@gmail.com");
		logger.info("emtered email address");
		myAccpg.enterLoginPassword("radhadabir");
		logger.info("entered password");
		myAccpg.clickLogin();
		logger.info("Clicked on Login Button");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		registeredUserAccount registeredUserAcc = new registeredUserAccount(driver);
		String userName = registeredUserAcc.getUserName();
		
		if(userName.equals("Radha dabir") ) {
			logger.info("Verify login --passed");
			
			Assert.assertTrue(true);
			
		} else {
			logger.info("Verify login --failed");
			captureScreenshots(driver,"verifyLogin");
			Assert.assertTrue(false);
		}
		driver.close();
		
	}

}
