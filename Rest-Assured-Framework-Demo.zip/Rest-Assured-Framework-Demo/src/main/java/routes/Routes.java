package routes;

public class Routes {
 
    // Routes for gorest.co.in
    public static String gorestbaseurl = "https://gorest.co.in";
    
    public static String post_url = gorestbaseurl + "/public/v2/users/";
    
    public static String get_url = gorestbaseurl+ "/public/v2/users";
    
    public static String update_url = gorestbaseurl+ "/public/v2/users/{id}";
    
    public static String delete_url = gorestbaseurl+ "/public/v2/users/{id}";
}
